﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace Racetracks
{
    class Car : Body
    {
        private Vector2 acceleration;
        private float drag = 0.98f;

        /// <summary>Creates a user controlled Car</summary>        
        public Car(Vector2 position) : base(position, "car")
        {
            offsetDegrees = -90;
        }

        /// <summary>Updates this Car</summary>        
        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            velocity += acceleration;
            acceleration = Vector2.Zero;
            velocity *= drag;
        }

        /// <summary>Handle user input for this Car</summary>        
        public override void HandleInput(InputHelper inputHelper)
        {
            base.HandleInput(inputHelper);

            float speed = 12;

            if (inputHelper.IsKeyDown(Keys.Left))
            {
                Degrees -= 3;
                velocity = Forward * velocity.Length();
            }
            if (inputHelper.IsKeyDown(Keys.Right))
            {
                Degrees += 3;
                velocity = Forward * velocity.Length();
            }
            if (inputHelper.IsKeyDown(Keys.Up))
            {
                acceleration += Forward * speed;
            }
            if (inputHelper.IsKeyDown(Keys.Down))
            {
                acceleration -= Forward * speed;
            }
        }

        public override void Reset()
        {
            base.Reset();
            velocity = Vector2.Zero;
        }
    }
}
